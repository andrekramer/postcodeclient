java -jar target/postcode-jar-with-dependencies.jar "CB3 0FA"
