package com.democode.postcodeclient;

import org.apache.http.client.HttpResponseException;
import org.junit.Test;
import org.junit.Assert;

import java.io.IOException;

/**
 * Tests for PostCodeClient.
 */
public class PostCodeClientTests {

    @Test
    public void encodePostCodeTest() {
        Assert.assertEquals("CB3%200FA", PostCodeClient.encode("CB3 0FA"));
    }

    @Test
    public void validatePostCodeTest() throws IOException {
        Assert.assertTrue(new PostCodeClient().validate("CB3 0FA"));
    }

    @Test
    public void invalidatePostCodeTest() throws IOException {
        Assert.assertFalse(new PostCodeClient().validate("XXXX"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void nullPostCodeTest() throws IOException {
        new PostCodeClient().validate(null);
    }

    @Test
    public void lookupPostCodeTest() throws IOException {
        PostCodeInfo response = new PostCodeClient().lookup("CB3 0FA");
        PostCodeInfo expected = new PostCodeInfo("CB3 0FA", "England", "East of England");
        Assert.assertEquals(expected, response);
    }

    @Test(expected = HttpResponseException.class)
    public void lookupInvalidPostCodeTest() throws IOException {
        new PostCodeClient().lookup("XXXX");
    }

    @Test
    public void countNearestPostCodesTest() throws IOException {
        PostCodeInfo[] response = new PostCodeClient().findNearest("CB3 0FA");

        Assert.assertEquals(3, response.length);
    }

    @Test(expected = HttpResponseException.class)
    public void findNearbysForInvalidPostCodeTest() throws IOException {
        new PostCodeClient().findNearest("XXXX");
    }
}
