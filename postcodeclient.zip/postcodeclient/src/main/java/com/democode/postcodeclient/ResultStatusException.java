package com.democode.postcodeclient;

import java.io.IOException;

/**
 * Exception for signaling that the status returned by the postcode API was not 200 as expected.
 */
public class ResultStatusException extends IOException {

    private static final int VALID_STATUS = 200;
    private int status;

    public ResultStatusException(int status, String msg) {
        super(msg);
        this.status = status;
    }

    public int getStatus() {
        return status;
    }

    public static void throwIfInvalid(int status, String msg) throws ResultStatusException {
        if (status != VALID_STATUS)
            throw new ResultStatusException(status, msg);
    }
}
