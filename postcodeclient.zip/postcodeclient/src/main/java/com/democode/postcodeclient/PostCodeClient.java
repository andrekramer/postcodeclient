package com.democode.postcodeclient;

import java.io.IOException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.http.*;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpResponseException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

/**
 * REST API client for looking up post codes on "postcodes.io".
 */
public final class PostCodeClient {

    private final static String endpoint = "http://api.postcodes.io/postcodes/";

    private final Gson gson = new GsonBuilder().create();

    public PostCodeClient() {
    }

    /**
     * Encode post codes for use in REST URL requests.
     * @param postCode the post code to encode
     * @return an encoded post code
     */
    public static String encode(String postCode) {
        // TODO use something like Spring's UriUtils.encodePath(path, "UTF-8"); or a URL builder.
        if (postCode == null || postCode.length() == 0 || postCode.contains("/"))
            throw new IllegalArgumentException("postcode");
        return postCode.replace(" ", "%20");
    }

    /**
     * Validate a post code.
     * @param postcode the post code to validate
     * @return true if the post code is valid; otherwise false
     * @throws IOException
     */
    public Boolean validate(String postcode) throws IOException {
        if (postcode == null || postcode.isEmpty())
            throw new IllegalArgumentException("postcode");

        try (CloseableHttpClient httpClient = HttpClients.createDefault())
        {
            HttpGet get = new HttpGet(endpoint + encode(postcode) + "/validate");
            get.setHeader("Content-Type", "application/json");

            ResponseHandler<ValidateResponse> responseHandler = new ResponseHandler<ValidateResponse>()
            {
                @Override
                public ValidateResponse handleResponse(final HttpResponse response) throws IOException
                {
                    HttpEntity entity = response.getEntity();

                    checkResponse(response.getStatusLine(), entity);
                    String json = EntityUtils.toString(entity);

                    return gson.fromJson(json, ValidateResponse.class);
                }
            };

            ValidateResponse response = httpClient.execute(get, responseHandler);
            ResultStatusException.throwIfInvalid(response.getStatus(), "Validate postcode response status is invalid");

            return response.getResult();
        }
    }

    /**
     * Lookup a post code.
     * @param postcode the post code to look up.
     * @return post code information for the given post code.
     * @throws IOException
     * TODO improve handling of invalid post codes
     * @exception HttpResponseException "Not found" if the post code is invalid.
     */
    public PostCodeInfo lookup(String postcode) throws IOException {
        if (postcode == null || postcode.isEmpty())
            throw new IllegalArgumentException("postcode");

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpGet get = new HttpGet(endpoint + encode(postcode));
            get.setHeader("Content-Type", "application/json");

            ResponseHandler<PostCodeResponse> responseHandler = new ResponseHandler<PostCodeResponse>() {
                @Override
                public PostCodeResponse handleResponse(final HttpResponse response) throws IOException {
                    HttpEntity entity = response.getEntity();

                    checkResponse(response.getStatusLine(), entity);
                    String json = EntityUtils.toString(entity);

                    return gson.fromJson(json, PostCodeResponse.class);
                }
            };

            PostCodeResponse response = httpClient.execute(get, responseHandler);
            ResultStatusException.throwIfInvalid(response.getStatus(), "Lookup postcode response status is invalid");

            return response.getResult();
        }
    }

    /**
     * Find nearby post codes for the given post code.
     * @param postcode the post code to find nearby post codes for
     * @return an array of PostCodeInfo objects
     * @throws IOException
     * TODO improve handling of invalid post codes
     * @exception HttpResponseException "Not found" if the post code is invalid.
     */
    public PostCodeInfo[] findNearest(String postcode) throws IOException {
        if (postcode == null || postcode.isEmpty())
            throw new IllegalArgumentException("postcode");

        try (CloseableHttpClient httpClient = HttpClients.createDefault())
        {
            HttpGet get = new HttpGet(endpoint + encode(postcode) + "/nearest");
            get.setHeader("Content-Type", "application/json");

            ResponseHandler<NearestResponse> responseHandler = new ResponseHandler<NearestResponse>()
            {
                @Override
                public NearestResponse handleResponse(final HttpResponse response) throws IOException
                {
                    HttpEntity entity = response.getEntity();

                    checkResponse(response.getStatusLine(), entity);
                    String json = EntityUtils.toString(entity);

                    return gson.fromJson(json, NearestResponse.class);
                }
            };

            NearestResponse response = httpClient.execute(get, responseHandler);
            ResultStatusException.throwIfInvalid(response.getStatus(), "Find nearest Response status is invalid");

            return response.getResult();
        }
    }

    private void checkResponse(StatusLine statusLine, HttpEntity entity) throws ClientProtocolException {
        if (statusLine.getStatusCode() >= 300)
            throw new HttpResponseException(statusLine.getStatusCode(), statusLine.getReasonPhrase());

        if (entity == null)
            throw new ClientProtocolException("Response contains no content");
    }
}
