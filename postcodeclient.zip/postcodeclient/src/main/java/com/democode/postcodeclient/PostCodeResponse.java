package com.democode.postcodeclient;

import java.io.Serializable;

/**
 * * Class for parsing of post code lookup responses.
 */
public class PostCodeResponse implements Serializable {

    private Integer status;
    private PostCodeInfo result;

    public PostCodeResponse(Integer status, PostCodeInfo result) {
        this.status = status;
        this.result = result;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public PostCodeInfo getResult() {
        return result;
    }

    public void setResult(PostCodeInfo postcode) {
        this.result = result;
    }
}
