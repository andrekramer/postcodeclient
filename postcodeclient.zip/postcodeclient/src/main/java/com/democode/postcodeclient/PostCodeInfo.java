package com.democode.postcodeclient;

import java.io.Serializable;

/**
 * * Class for parsing of post code information responses.
 */
public class PostCodeInfo implements Serializable {

    private String postcode;
    private String country;
    private String region;

    public PostCodeInfo(String postcode, String country, String region) {
        this.postcode = postcode;
        this.country = country;
        this.region = region;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String postcode) {
        this.country = country;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    @Override public boolean equals(Object other) {
        if (other == null || getClass() != other.getClass()) {
            return false;
        }
        PostCodeInfo postcodeInfo = (PostCodeInfo) other;
        return postcode.equals(postcodeInfo.getPostcode()) &&
                region.equals(postcodeInfo.getRegion()) &&
                country.equals(postcodeInfo.getCountry());
    }

    @Override public int hashCode() {
        return (postcode + region + country).hashCode();
    }
}
