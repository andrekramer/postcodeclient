package com.democode.postcodeclient;

import java.io.Serializable;

/**
 * Class for parsing of nearest post code responses.
 */
public class NearestResponse implements Serializable {

    private Integer status;
    private PostCodeInfo[] result;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public PostCodeInfo[] getResult() {
        return result;
    }

    public void setResult(PostCodeInfo[] result) {
        this.result = result;
    }
}

