package com.democode.postcodeclient;

import java.io.Serializable;

/**
 * Class for parsing of validate post code responses.
 */
public class ValidateResponse implements Serializable {

    private Integer status;
    private Boolean result;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Boolean getResult() {
        return result;
    }

    public void setResult(Boolean result) {
        this.result = result;
    }
}
