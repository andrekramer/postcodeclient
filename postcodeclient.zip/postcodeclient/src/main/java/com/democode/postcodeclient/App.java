package com.democode.postcodeclient;

import java.io.IOException;

/**
 * A simple example Java Main for looking up post code information.
 */
public final class App {

    public static void main(String[] args) {
        if (args.length != 1) {
            System.err.println("Invalid arguments => Expected a single post code argument.");
        } else {
            String postcode = args[0];
            System.out.print("Post code " + postcode);

            try {
                PostCodeClient client = new PostCodeClient();
                if (client.validate(postcode)) {
                    System.out.println(" is valid.");

                    PostCodeInfo postcodeInfo = client.lookup(postcode);
                    System.out.println(String.format("It is in region \"%s\" of country %s.",
                            postcodeInfo.getRegion(), postcodeInfo.getCountry()));

                    for (PostCodeInfo nearbyPostcodeInfo : client.findNearest(postcode)) {
                        System.out.println(String.format("\t%s in region \"%s\" of country %s is nearby.",
                                nearbyPostcodeInfo.getPostcode(), nearbyPostcodeInfo.getRegion(), nearbyPostcodeInfo.getCountry()));
                    }
                } else {
                    System.out.println(" is invalid!");
                }
            } catch (IOException ioe) {
                System.err.println("Looking up postcode failed with IOException: " + ioe);
            }
        }
    }
}
